from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        # USER = 'aacuser2'
        # PASS = 'Matt_Knutson'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32547
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
                
        print ('You have been successfully connected.')
        
        
        

# Complete this create method to implement the C in CRUD. #
    def create(self, newData):
                
        if newData is not None:
            self.database.animals.insert_one(newData)  # Data should be dictionary. #
            
            print('Your entry has been added to the database')
        
        else:
            raise Exception('Nothing to add to the database!!')
            
            
            
# Complete this read method to implement the R in CRUD. #
    def read(self, searchData):
                
        try:
        
            if searchData is not None:
                foundEntry = self.database.animals.find(searchData)  # Data should be a key/value pair. # 
            
                return foundEntry
                        
            else:
                raise Exception('Nothing to find!!')
                
        except KeyError:
            print('KEY does not exist in the database')
                
                  
            
            
# Complete this update method to implement the U in CRUD. #
    def update(self, searchData, updatedData):
                
        try:
        
            if searchData is not None:
                updated = self.database.animals.update_one(searchData, {"$set": updatedData}) # Data should be a key/value pair #                                                                                                      #    to search,   #
                print(str(updated.modified_count) + ' document updated.')                    #  & a key/value pair to update.  #
                                        
            else:
                raise Exception('Nothing to update for the database!!')
                
        except KeyError:
            print('KEY does not exist in the database')
        
        


# Complete this delete method to implement the D in CRUD. #
    def delete(self, deleteData):
                
        try:
        
            if deleteData is not None:
                deleted = self.database.animals.delete_one(deleteData)  # Data should be a key/value pair. #
                
                print(str(deleted.deleted_count) + ' file has been deleted.')
                        
            else:
                raise Exception('Nothing to delete!!')
                
        except KeyError:
            print('KEY does not exist in the database')
        
        



